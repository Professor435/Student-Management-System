from django.urls import path
from .views import teacher_dashboard, course_students, update_grade, student_grades

urlpatterns = [
    path('teacher/dashboard/', teacher_dashboard, name='teacher_dashboard'),
    path('course/<int:course_id>/students/', course_students, name='course_students'),
    path('enrollment/<int:enrollment_id>/grade/', update_grade, name='update_grade'),
    path('student/grades/', student_grades, name='student_grades'),
]