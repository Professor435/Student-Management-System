from django.contrib import admin
from .models import Course, CourseAssignment, StudentEnrollment, Grade

class GradeInline(admin.TabularInline):
    model = Grade

class StudentEnrollmentAdmin(admin.ModelAdmin):
    inlines = [GradeInline]

admin.site.register(Course)
admin.site.register(CourseAssignment)
admin.site.register(StudentEnrollment, StudentEnrollmentAdmin)
admin.site.register(Grade)