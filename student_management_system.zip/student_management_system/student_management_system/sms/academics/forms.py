from django import forms
from .models import Course, CourseAssignment, StudentEnrollment, Grade

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = '__all__'

class CourseAssignmentForm(forms.ModelForm):
    class Meta:
        model = CourseAssignment
        fields = '__all__'

class StudentEnrollmentForm(forms.ModelForm):
    class Meta:
        model = StudentEnrollment
        fields = ['student', 'course_assignment']

class GradeForm(forms.ModelForm):
    class Meta:
        model = Grade
        fields = ['mid_term', 'final_term', 'sessional', 'remarks']