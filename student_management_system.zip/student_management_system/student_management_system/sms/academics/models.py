from django.db import models
from accounts.models import Student, Teacher

class Course(models.Model):
    code = models.CharField(max_length=20, unique=True)
    title = models.CharField(max_length=100)
    credit_hours = models.IntegerField()
    description = models.TextField(blank=True)
    
    def __str__(self):
        return f"{self.code} - {self.title}"

class CourseAssignment(models.Model):
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    semester = models.IntegerField()
    section = models.CharField(max_length=10)
    
    class Meta:
        unique_together = ('course', 'semester', 'section')
    
    def __str__(self):
        return f"{self.course} - {self.semester}-{self.section}"

class StudentEnrollment(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course_assignment = models.ForeignKey(CourseAssignment, on_delete=models.CASCADE)
    enrollment_date = models.DateField(auto_now_add=True)
    
    class Meta:
        unique_together = ('student', 'course_assignment')
    
    def __str__(self):
        return f"{self.student} in {self.course_assignment}"

class Grade(models.Model):
    GRADE_CHOICES = [
        ('A+', 'A+'), ('A', 'A'), ('A-', 'A-'),
        ('B+', 'B+'), ('B', 'B'), ('B-', 'B-'),
        ('C+', 'C+'), ('C', 'C'), ('C-', 'C-'),
        ('D+', 'D+'), ('D', 'D'), ('F', 'F'),
    ]
    
    enrollment = models.OneToOneField(StudentEnrollment, on_delete=models.CASCADE)
    mid_term = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    final_term = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    sessional = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    total = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    grade = models.CharField(max_length=2, choices=GRADE_CHOICES, null=True, blank=True)
    remarks = models.TextField(blank=True)
    
    def save(self, *args, **kwargs):
        if self.mid_term is not None and self.final_term is not None and self.sessional is not None:
            self.total = self.mid_term + self.final_term + self.sessional
            
            # Simple grade calculation (adjust as needed)
            if self.total >= 90:
                self.grade = 'A+'
            elif self.total >= 85:
                self.grade = 'A'
            elif self.total >= 80:
                self.grade = 'A-'
            elif self.total >= 75:
                self.grade = 'B+'
            elif self.total >= 70:
                self.grade = 'B'
            elif self.total >= 65:
                self.grade = 'B-'
            elif self.total >= 60:
                self.grade = 'C+'
            elif self.total >= 55:
                self.grade = 'C'
            elif self.total >= 50:
                self.grade = 'C-'
            elif self.total >= 45:
                self.grade = 'D+'
            elif self.total >= 40:
                self.grade = 'D'
            else:
                self.grade = 'F'
        
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"Grade for {self.enrollment}"