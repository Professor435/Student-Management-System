from django.shortcuts import render, redirect, get_object_or_404  # Added redirect here
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import CourseAssignment, StudentEnrollment, Grade
from .forms import GradeForm
from accounts.models import Teacher, Student

@login_required
def teacher_dashboard(request):
    if not request.user.is_teacher:
        return redirect('home')
    
    teacher = request.user.teacher
    courses = CourseAssignment.objects.filter(teacher=teacher)
    
    # Calculate total students (better than doing it in template)
    total_students = sum(course.studentenrollment_set.count() for course in courses)
    
    context = {
        'teacher': teacher,
        'courses': courses,
        'total_students': total_students,
    }
    
    return render(request, 'academics/teacher_dashboard.html', context)

@login_required
def course_students(request, course_id):
    if not request.user.is_teacher:
        return redirect('home')
    
    course = get_object_or_404(CourseAssignment, id=course_id, teacher=request.user.teacher)
    enrollments = StudentEnrollment.objects.filter(course_assignment=course).select_related('student')
    
    context = {
        'course': course,
        'enrollments': enrollments,
    }
    
    return render(request, 'academics/course_students.html', context)

@login_required
def update_grade(request, enrollment_id):
    if not request.user.is_teacher:
        return redirect('home')
    
    enrollment = get_object_or_404(StudentEnrollment, id=enrollment_id)
    grade, created = Grade.objects.get_or_create(enrollment=enrollment)
    
    if request.method == 'POST':
        form = GradeForm(request.POST, instance=grade)
        if form.is_valid():
            form.save()
            messages.success(request, 'Grade updated successfully!')
            return redirect('course_students', course_id=enrollment.course_assignment.id)
    else:
        form = GradeForm(instance=grade)
    
    context = {
        'form': form,
        'enrollment': enrollment,
    }
    
    return render(request, 'academics/update_grade.html', context)

@login_required
def student_grades(request):
    if not request.user.is_student:
        return redirect('home')
    
    student = request.user.student
    enrollments = StudentEnrollment.objects.filter(student=student).select_related(
        'course_assignment', 
        'course_assignment__course', 
        'course_assignment__teacher'
    )
    
    context = {
        'student': student,
        'enrollments': enrollments,
    }
    
    return render(request, 'academics/student_grades.html', context)