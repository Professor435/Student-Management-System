from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import UpdateView
from django.urls import reverse_lazy
from .forms import UserRegisterForm, StudentProfileForm, TeacherProfileForm, UserUpdateForm
from .models import User, Student, Teacher

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}!')
            login(request, user)
            return redirect('profile_setup')
    else:
        form = UserRegisterForm()
    return render(request, 'accounts/register.html', {'form': form})

def profile_setup(request):
    if not request.user.is_authenticated:
        return redirect('login')
    
    if request.method == 'POST':
        if request.user.is_student:
            form = StudentProfileForm(request.POST)
        elif request.user.is_teacher:
            form = TeacherProfileForm(request.POST)
        else:
            return redirect('home')
        
        if form.is_valid():
            profile = form.save(commit=False)
            profile.user = request.user
            profile.save()
            messages.success(request, 'Your profile has been updated!')
            return redirect('profile')
    else:
        if request.user.is_student:
            form = StudentProfileForm()
        elif request.user.is_teacher:
            form = TeacherProfileForm()
        else:
            return redirect('home')
    
    return render(request, 'accounts/profile_setup.html', {'form': form})

@login_required
def profile(request):
    context = {}
    
    if request.user.is_student:
        context['profile'] = request.user.student
    elif request.user.is_teacher:
        context['profile'] = request.user.teacher
    
    return render(request, 'accounts/profile.html', context)

class ProfileUpdateView(LoginRequiredMixin, UpdateView):
    model = User
    form_class = UserUpdateForm
    template_name = 'accounts/profile_update.html'
    success_url = reverse_lazy('profile')
    
    def get_object(self):
        return self.request.user
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        if self.request.user.is_student:
            context['student_profile'] = self.request.user.student
        elif self.request.user.is_teacher:
            context['teacher_profile'] = self.request.user.teacher
        return context

def custom_logout(request):
    if request.user.is_authenticated:
        logout(request)
    return redirect('home')

def contact_us(request):
    # Simple view that just renders the contact template
    return render(request, 'accounts/contact.html')