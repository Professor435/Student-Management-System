from django.urls import path
from .views import register, profile_setup, profile, ProfileUpdateView, custom_logout
from django.contrib.auth.views import LoginView
from accounts.views import contact_us

urlpatterns = [
    path('register/', register, name='register'),
    path('login/', LoginView.as_view(template_name='accounts/login.html'), name='login'),
    path('logout/', custom_logout, name='logout'),
    path('profile/setup/', profile_setup, name='profile_setup'),
    path('profile/', profile, name='profile'),
    path('profile/update/', ProfileUpdateView.as_view(), name='profile_update'),
    path('contact/', contact_us, name='contact_us'),
]