from django import template

register = template.Library()

@register.simple_tag
def add_to_var(value):
    return value